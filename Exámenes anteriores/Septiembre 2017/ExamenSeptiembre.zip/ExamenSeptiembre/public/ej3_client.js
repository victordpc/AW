

$(document).ready(function () {
    //
    // Apartado 3.a y 3.b
    //
});

