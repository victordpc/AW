"use strict";


// ----------------------------------
// Realiza aquí el apartado 2.(a)
// ----------------------------------
function actualizarRanking() {
    
    // Eliminamos las filas de la tabla
    $("#ranking tbody tr").remove();

    // Continúa aquí el apartado (a)
}


$(document).ready(function () {
    actualizarRanking();
    registrarEventoRanking();
});